local g = golly()
local gp = require "gplus"

-- re-assigning inner loop functions results in a 10% speed up
local setcell = g.setcell
local getcell = g.getcell

g.new("test-pattern")
g.setrule("rotary-split-join")

for r = 0, 127 do
  for c = 0, 127 do
    setcell(5*r, 5*c, 4)
    if (math.random() < 0.5) then
      setcell(5*r, 5*c+1, 3)
      setcell(5*r, 5*c-1, 3)
    else
      setcell(5*r+1, 5*c, 3)
      setcell(5*r-1, 5*c, 3)
    end
  end
  setcell(5*r+2, -3, 3)
  setcell(5*r-2, -3, 3)
  setcell(5*r+1, -4, 3)
  setcell(5*r-1, -4, 3)
  setcell(5*r+2, 638, 3)
  setcell(5*r-2, 638, 3)
  setcell(5*r+1, 639, 3)
  setcell(5*r-1, 639, 3)
  setcell(-3, 5*r+2, 3)
  setcell(-3, 5*r-2, 3)
  setcell(-4, 5*r+1, 3)
  setcell(-4, 5*r-1, 3)
  setcell(638, 5*r+2, 3)
  setcell(638, 5*r-2, 3)
  setcell(639, 5*r+1, 3)
  setcell(639, 5*r-1, 3)
end
g.fit()